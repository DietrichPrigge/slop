#include <Arduino.h>
#include <Notecard.h>
#include <Adafruit_PM25AQI.h> // Air Quality Sensor
#include <Adafruit_INA260.h> // Voltage, Current, Power Sensor
#include <Adafruit_AHTX0.h> // Air Temperature and Humidity Sensor

#define productUID "edu.umn.d.prigg071:ite_project"  // Product UID for Notecard
// Object declaration for the AHTX0 sensor
Adafruit_AHTX0 aht;
Adafruit_INA260 ina260;
Adafruit_PM25AQI aqi;
Notecard notecard;

// Variables to store time and location data
char yyyy[5];
char mM[3];
char dd[3];
char hh[3];
char mm[3];
char ss[3];
double lat;
double lon;

// Variables to store temperature and humidity
float temperature;
float humidity;
float current;
float voltage;
float power;
// Variables to store particulate matter concentrations
float pm10_standard;
float pm25_standard;
float pm100_standard;
float pm10_env;
float pm25_env;
float pm100_env;
// Variables to store particle counts
uint16_t particles_03um;
uint16_t particles_05um;
uint16_t particles_10um;
uint16_t particles_25um;
uint16_t particles_50um;
uint16_t particles_100um;

// Function prototypes
void Read_AHTX0();
void Read_INA260();
void Read_PM25AQI();
void Print_Data();
void Notecard_Find_Location();
void Send_Data();
void Set_Time_Location(J *rsp);

void setup()
{
delay(2000); // Initial delay to allow peripherals to stabilize
Serial.begin(115200); // Initialize serial for debugging

// Initialize the AHTX0 sensor (Temperature & Humidity)
if (! aht.begin()) {
Serial.println("Could not find AHTX0 sensor!");
while (1); // Stop the program if the sensor is not found
}
Serial.println("AHTX0 sensor found!");

// Initialize the INA260 sensor (Power, Current, Voltage)
if (!ina260.begin()) {
Serial.println("Could not find INA260 sensor!");
while (1); // Stop the program if the sensor is not found
}
Serial.println("INA260 sensor found!");

// Set to average over 16 samples
ina260.setAveragingCount(INA260_COUNT_16);

// Initialize the PM2.5 AQI sensor
if (!aqi.begin_I2C()) {
Serial.println("Could not find PM 2.5 sensor!");
while (1); // Stop the program if the sensor is not found
}
Serial.println("PM2.5 sensor found!");


notecard.setDebugOutputStream(Serial); // Set Notecard to output debug info over serial
notecard.begin(); // Initialize the Notecard

// Set up the Notecard for hub communication
{
J *req = notecard.newRequest("hub.set");
JAddStringToObject(req, "product", productUID);
JAddStringToObject(req, "mode", "periodic"); // Periodic communication mode
JAddNumberToObject(req, "inbound", 60 * 12); // Set inbound interval (12 minutes)
JAddNumberToObject(req, "outbound", 30); // Set outbound interval (30 seconds)
if (!notecard.sendRequest(req)) {
JDelete(req); // Delete the request if sending fails
}
}

// Enable DFU (Device Firmware Update) mode on the Notecard
{
J *req = notecard.newRequest("card.aux");
JAddStringToObject(req, "mode", "dfu"); // Set auxiliary card mode to DFU
if (!notecard.sendRequest(req)) {
JDelete(req); // Delete the request if sending fails
}
}

// Set up periodic location tracking (every 5 minutes)
{
J *req = notecard.newRequest("card.location.mode");
JAddStringToObject(req, "mode", "periodic");
JAddNumberToObject(req, "seconds", 60 * 5); // Set location interval to 5 minutes
if (!notecard.sendRequest(req)) {
JDelete(req); // Delete the request if sending fails
}
}

}

void loop()
{
// record the start time
unsigned long startTime = millis();
Read_AHTX0(); // Read the sensor data
Read_INA260(); // Read the sensor data
Read_PM25AQI(); // Read the sensor data
Print_Data(); // Print the data to Serial
// execute tasks: find location and send data
Notecard_Find_Location();
Send_Data();

// delay(5000); // Wait for 5 seconds before reading again
//spin the CPU until 5 minutes (300,000 ms) have passed
while (millis() - startTime < 10000){
//busy-wait to ensure the loop runs for exactly 5 minutes
// change to 15 minutes for deployment
}
}

void Read_AHTX0()
{
// Read temperature and humidity from AHTX0 sensor
sensors_event_t humid, temp;
aht.getEvent(&humid, &temp);
temperature = temp.temperature; // Store temperature value
humidity = humid.relative_humidity; // Store humidity value
}

void Read_INA260()
{
// Read current, voltage, and power from INA260 sensor
current = ina260.readCurrent(); // Store current value
voltage = ina260.readBusVoltage(); // Store voltage value
power = ina260.readPower(); // Store power value
}

void Read_PM25AQI()
{
PM25_AQI_Data data;
// Read air quality data from PM2.5 AQI sensor
if (aqi.read(&data)) {
pm10_standard = data.pm10_standard; // Store PM1.0 concentration (standard)
pm25_standard = data.pm25_standard; // Store PM2.5 concentration (standard)
pm100_standard = data.pm100_standard; // Store PM10 concentration (standard)
pm10_env = data.pm10_env; // Store PM1.0 concentration (environmental)
pm25_env = data.pm25_env; // Store PM2.5 concentration (environmental)
pm100_env = data.pm100_env; // Store PM10 concentration (environmental)
particles_03um = data.particles_03um; // Particles > 0.3um / 0.1L air
particles_05um = data.particles_05um; // Particles > 0.5um / 0.1L air
particles_10um = data.particles_10um; // Particles > 1.0um / 0.1L air
particles_25um = data.particles_25um; // Particles > 2.5um / 0.1L air
particles_50um = data.particles_50um; // Particles > 5.0um / 0.1L air
particles_100um = data.particles_100um; // Particles > 50um / 0.1L air
}
}


void Print_Data()
{
// Print time
Serial.print("YYYY: ");
Serial.println(yyyy);
Serial.print("MM: ");
Serial.println(mM);
Serial.print("DD: ");
Serial.println(dd);
Serial.print("hh: ");
Serial.println(hh);
Serial.print("mm: ");
Serial.println(mm);
Serial.print("ss: ");
Serial.println(ss);

// Print location
Serial.print("latitude: ");
Serial.println(lat);
Serial.print("longitude: ");
Serial.println(lon);

// Print the temperature and humidity to the Serial monitor
Serial.print("Temperature: ");
Serial.print(temperature);
Serial.println(" °C");

Serial.print("Humidity: ");
Serial.print(humidity);
Serial.println(" %");

// Print the current, voltage, and power to the Serial monitor
Serial.print("Current: ");
Serial.print(current);
Serial.println(" mA");

Serial.print("Bus Voltage: ");
Serial.print(voltage);
Serial.println(" mV");

Serial.print("Power: ");
Serial.print(power);
Serial.println(" mW");

// Print the particulate matter concentrations to the Serial monitor
Serial.print("PM1.0 (standard): ");
Serial.print(pm10_standard);
Serial.println(" µg/m³");

Serial.print("PM2.5 (standard): ");
Serial.print(pm25_standard);
Serial.println(" µg/m³");

Serial.print("PM10 (standard): ");
Serial.print(pm100_standard);
Serial.println(" µg/m³");

Serial.print("PM1.0 (environmental): ");
Serial.print(pm10_env);
Serial.println(" µg/m³");

Serial.print("PM2.5 (environmental): ");
Serial.print(pm25_env);
Serial.println(" µg/m³");

Serial.print("PM10 (environmental): ");
Serial.print(pm100_env);
Serial.println(" µg/m³");

// Print particle counts for different sizes
Serial.print("Particles > 0.3um / 0.1L air: ");
Serial.println(particles_03um);

Serial.print("Particles > 0.5um / 0.1L air: ");
Serial.println(particles_05um);

Serial.print("Particles > 1.0um / 0.1L air: ");
Serial.println(particles_10um);

Serial.print("Particles > 2.5um / 0.1L air: ");
Serial.println(particles_25um);

Serial.print("Particles > 5.0um / 0.1L air: ");
Serial.println(particles_50um);

Serial.print("Particles > 50um / 0.1L air: ");
Serial.println(particles_100um);

Serial.print("Out Team number is Team 0");

Serial.println();

}

void Notecard_Find_Location()
{
size_t gps_time_s;

// Fetch the current location from the Notecard
{
J *rsp = notecard.requestAndResponse(notecard.newRequest("card.location"));
gps_time_s = JGetInt(rsp, "time"); // Get the GPS time
NoteDeleteResponse(rsp);

}                                                                                       
// Switch the Notecard to continuous location tracking mode
{
J *req = notecard.newRequest("card.location.mode");
JAddStringToObject(req, "mode", "continuous");
notecard.sendRequest(req);
}

size_t timeout_s = 600; // 10-minute timeout for finding a location

// Poll for updated location data
for (const size_t start_ms = ::millis();;) {
if (::millis() >= (start_ms + (timeout_s * 1000))) {
Serial.println("Timed out looking for a location\n");
break; // Timeout reached, stop looking for location
}
J *rsp = notecard.requestAndResponse(notecard.newRequest("card.location"));
if (JGetInt(rsp, "time") != gps_time_s) { // Check if GPS time has updated
Set_Time_Location(rsp); // If updated, set the time and location
NoteDeleteResponse(rsp);

// Switch the Notecard back to periodic location mode
{
J *req = notecard.newRequest("card.location.mode");
JAddStringToObject(req, "mode", "periodic");
notecard.sendRequest(req);
}
break;
}
if (JGetObjectItem(rsp, "stop")) { // If stop flag is found, break out
Serial.println("Found a stop flag, cannot find location\n");
break;
}
NoteDeleteResponse(rsp);
delay(2000); // Wait 2 seconds between location requests
}
}

void Set_Time_Location(J *rsp)
{
// Parse and set the time and location from the Notecard response
time_t rawtime;
rawtime = JGetNumber(rsp, "time");

lon = JGetNumber(rsp, "lon");
lon = (floor(100000*lon)/100000); // Truncate longitude to 5 decimal places
lat = JGetNumber(rsp, "lat");
lat = (floor(100000*lat)/100000); // Truncate latitude to 5 decimal places

struct tm ts;
ts = *localtime(&rawtime); // Convert raw time to local time
strftime(yyyy, sizeof(yyyy), "%Y", &ts);
strftime(mM, sizeof(mM), "%m", &ts);
strftime(dd, sizeof(dd), "%d", &ts);
strftime(hh, sizeof(hh), "%H", &ts);
strftime(ss, sizeof(ss), "%S", &ts);
strftime(mm, sizeof(mm), "%M", &ts);
}

void Send_Data()
{
// Create a Notecard request to send data (date/time and extra info)
J *req = notecard.newRequest("note.add");
if (req != NULL)
{
JAddStringToObject(req, "file", "data.qo"); // Store data in "data.qo" file
JAddBoolToObject(req, "sync", true); // Request immediate sync
J *body = JAddObjectToObject(req, "body");
if (body)
{
// Add time data
JAddStringToObject(body, "YYYY", yyyy);
JAddStringToObject(body, "MM", mM);
JAddStringToObject(body, "DD", dd);
JAddStringToObject(body, "hh", hh);
JAddStringToObject(body, "mm", mm);
JAddStringToObject(body, "ss", ss);

// send location data
JAddNumberToObject(body, "lat", lat);
JAddNumberToObject(body, "lon", lon);

// send temperature and humidity data
JAddNumberToObject(body,"temperature",temperature);
JAddNumberToObject(body,"humidity",humidity);

// send power current data
JAddNumberToObject(body,"current",current);
JAddNumberToObject(body,"voltage",voltage);
JAddNumberToObject(body,"power",power);

// send air quality data
JAddNumberToObject(body,"pm10_standard",pm10_standard);
JAddNumberToObject(body,"pm25_standard",pm25_standard);
JAddNumberToObject(body,"pm100_standard",pm100_standard);
JAddNumberToObject(body,"pm10_env",pm10_env);
JAddNumberToObject(body,"pm25_env",pm25_env);
JAddNumberToObject(body,"pm100_env",pm100_env);

JAddNumberToObject(body,"particles_03um",particles_03um);
JAddNumberToObject(body,"particles_05um",particles_05um);
JAddNumberToObject(body,"particles_10um",particles_10um);
JAddNumberToObject(body,"particles_25um",particles_25um);
JAddNumberToObject(body,"particles_50um",particles_50um);
JAddNumberToObject(body,"particles_100um",particles_100um);

}

notecard.sendRequest(req); // Send the request to the Notecard
}
}